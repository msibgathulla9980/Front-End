/**
 * @module
 * @description
 * Entry point for all public APIs of the Angular Module
 */
export * from './src/index';
