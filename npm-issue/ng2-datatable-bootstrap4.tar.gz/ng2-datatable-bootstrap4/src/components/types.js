var DataTableTranslations = (function () {
    function DataTableTranslations() {
    }
    return DataTableTranslations;
}());
export { DataTableTranslations };
export var defaultTranslations = {
    indexColumn: 'index',
    selectColumn: 'select',
    expandColumn: 'expand',
    paginationLimit: 'Limit',
    paginationRange: 'Results'
};
var DataTableParams = (function () {
    function DataTableParams() {
    }
    return DataTableParams;
}());
export { DataTableParams };
//# sourceMappingURL=types.js.map