export { DataTableModule } from './data-table.module';
//# sourceMappingURL=index.js.map